package com.internshala;

import java.sql.Statement;
import java.sql.*;
import java.util.Scanner;

public class BusTicket{
	private static Connection connection = null;

	private static Scanner scanner =new Scanner(System.in);
	public static void main(String[]args){
		BusTicket busTicket = new BusTicket();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver"); //load and register driver

			//establishing connection
			String dbUrl = "jdbc:mysql://localhost:3307/busticket";
			String username = "root";
			String password = "";
			connection = DriverManager.getConnection(dbUrl, username, password);
			while (true){

				System.out.println("Enter choice");
			System.out.println("1. User Register");
			System.out.println("2. User Login");
			System.out.println("3. Admin Login");

			int choice = Integer.parseInt(scanner.nextLine());

			switch (choice) {
				case 1:
					busTicket.UserRegisteration();
					break;
				case 2:
					busTicket.UserLogin();
					break;
				case 3:
					busTicket.AdminLOgin();
					break;


			}
		}



		} catch (Exception e) {
			throw new RuntimeException("Something went wrong");

		}
	}
	//for registering user
	private void UserRegisteration()throws SQLException {

		String sql = "insert into users(FullName,MobileNumber,email,username,password)values(?,?,?,?,?)";
		// prepared statement is a interface used when we have to insert multiple values

		PreparedStatement preparedStatement = connection.prepareStatement(sql);

		System.out.println("Enter Full Name");
		preparedStatement.setString(1,scanner.nextLine());

		System.out.println("Enter Mobile number");
		preparedStatement.setString(2,scanner.nextLine());

		System.out.println("Enter email");
		preparedStatement.setString(3,scanner.nextLine());

		System.out.println("Enter username");
		preparedStatement.setString(4,scanner.nextLine());

		System.out.println("Enter password");
		preparedStatement.setString(5,scanner.nextLine());


		int rows = preparedStatement.executeUpdate();
		if (rows>0){
			System.out.println("User registered successfully");
			System.out.println();

		}

	}
	// Funnction if user already exists
	private void UserLogin()throws SQLException{

		Statement stmt =connection.createStatement();
		System.out.println("Enter username");
		String username = scanner.nextLine();

		System.out.println("Enter password");
		String password = scanner.nextLine();
		String sql= "Select * from users where username='"+username+"' and password='"+password+"'";
		ResultSet resultSet =stmt.executeQuery(sql);
		// Resultset is like a cursor that moves in vertical direction in a table and fetches all the rows

		if(resultSet.next()){

			System.out.println("logged in successfully");
			System.out.println();

			Menudriven();

		} else{
			System.out.println("username or password incorrect");
		}
			
	}
// Function for admin login
	private void AdminLOgin()throws SQLException {


		String username, password;
		System.out.println("Enter username");
		username = scanner.nextLine();
		System.out.println("Enter password");
		password = scanner.nextLine();
		while (true){
		if (username.equals("roh123") && (password.equals("rohit123"))) {
			System.out.println("Admin logged in successfully");
			System.out.println("Enter choice");
			System.out.println("1. Add buses");
			System.out.println("2. View the booked tickets");
			System.out.println("3. View the user details");
			System.out.println("4. To return to main menu");

			int choice = Integer.parseInt(scanner.nextLine());
			switch (choice){
				case 1:
					BusAdding();
					break;
				case 2:
					ViewBookedTickets();
					break;
				case 3:
					ViewUsersDetails();
					break;
				case 4:
					return ;

					default:
					break;
			}

		} else {
			System.out.println("username or password incorrect");
		}}
	}

// Function for admin to add buses and buses details
	private void BusAdding()throws SQLException{
		String sql = "insert into buses(BusNumber,Source,Destination,SourceTime,DestinationTime)values(?,?,?,?,?)";

		PreparedStatement preparedStatement = connection.prepareStatement(sql);


		System.out.println("Enter Bus number");
		preparedStatement.setString(1,scanner.nextLine());

		System.out.println("Enter Source");
		preparedStatement.setString(2,scanner.nextLine());

		System.out.println("Enter Destination");
		preparedStatement.setString(3,scanner.nextLine());

		System.out.println("Enter Starting Time");
		preparedStatement.setString(4,scanner.nextLine());

		System.out.println("Enter Reaching Time");
		preparedStatement.setString(5,scanner.nextLine());
		int rows = preparedStatement.executeUpdate();
		if (rows>0) {
			System.out.println("Bus Added successfully");
		}

	}
	// Function for users to book tickets
	private void BookTickets()throws SQLException{
		String sql = "insert into tickets(FullName,MobileNumber,Source,Destination)values(?,?,?,?)";


		PreparedStatement preparedStatement = connection.prepareStatement(sql);
		System.out.println("Enter the followig details: ");
		System.out.println();

		System.out.println("Enter name of the person");
		preparedStatement.setString(1,scanner.nextLine());

		System.out.println("Enter Mobile number");
		preparedStatement.setString(2,scanner.nextLine());

		System.out.println("Enter Source");
		preparedStatement.setString(3,scanner.nextLine());

		System.out.println("Enter Destination");
		preparedStatement.setString(4,scanner.nextLine());


		int rows = preparedStatement.executeUpdate();
		if (rows>0) {
			System.out.println("Ticket Added successfully");
		}



	}
	// function for users to  view buses available
	private void ViewTicketsAvailable()throws SQLException{
		Statement stmt =connection.createStatement();
		String sql = " SELECT * FROM buses";
		ResultSet resultSet =stmt.executeQuery(sql);

		//ResultSetMetaData used to get info from resultset like how many columns,column names etc.

		String id,BusNumber,Source,	Destination,SourceTime,DestinationTime;
		System.out.println("id | BusNumber | Source | Destination | SourceTime | DestinationTime \n");
		while(resultSet.next()){
			id= resultSet.getString(1);
			BusNumber= resultSet.getString(2);
			Source= resultSet.getString(3);
			Destination= resultSet.getString(4);
			SourceTime= resultSet.getString(5);
			DestinationTime= resultSet.getString(6);
			System.out.println(id+"  "+BusNumber+"       "+Source+"      "+
					Destination+"      "+SourceTime+"        "+DestinationTime+"   ");

		}




	}
	//function for admin to view the customers who had booked the tickets
	private void ViewBookedTickets()throws SQLException {
		Statement stmt = connection.createStatement();
		String sql = " SELECT * FROM tickets";
		ResultSet resultSet = stmt.executeQuery(sql);

		//ResultSetMetaData used to get info from resultset like how many columns,column names etc.

		String TicketNO,FullName,MobileNumber,Source, Destination;
		System.out.println("TicketNO       |       FullName       |       MobileNumber      |       Source     |       Destination\n");
		while (resultSet.next()) {
			TicketNO = resultSet.getString(1);
			FullName= resultSet.getString(2);
			MobileNumber= resultSet.getString(3);
			Source = resultSet.getString(4);
			Destination = resultSet.getString(5);
			System.out.println(TicketNO + "                   " + FullName + "                 " + MobileNumber+
					"               " +
					Source + "               " +Destination+ " " );

		}
	}
	//function for customers to update their passwords
	private void UpdatePassword()throws SQLException{

		System.out.println("Enter your username");
		String username = scanner.nextLine();

		String sql = "UPDATE users SET password=? WHERE username='"+username+"'";
		PreparedStatement preparedStatement = connection.prepareStatement(sql);
		System.out.println("Set new password");
		preparedStatement.setString(1,scanner.nextLine());
		int rows = preparedStatement.executeUpdate();
		if (rows>0) {
			System.out.println("Password updated successfully");
		}

	}
	//function for customers to delete their tickets
	private void DeleteTickets()throws SQLException{
		System.out.println("Enter your TicketNO");
		Integer TicketNO = scanner.nextInt();
		String sql = "DELETE from tickets WHERE TicketNo='"+TicketNO+"'";
		PreparedStatement preparedStatement = connection.prepareStatement(sql);
		int rows = preparedStatement.executeUpdate();
		if (rows>0) {
			System.out.println("Ticket Deleted successfully");
		}



	}
	// Menudriven function to reduce the code length

	private void Menudriven()throws SQLException{
		while (true){

		System.out.println("Press 1 to view the details of the buses and to book the tickets");

		System.out.println("Press 2 if you want to update your password");
		System.out.println("Press 3 to delete tickets");
		System.out.println("Press 4 to return to main menu");


		int choice = Integer.parseInt(scanner.nextLine());
		switch (choice){
			case 1:
				ViewTicketsAvailable();BookTickets();
				break;

			case 2:
				UpdatePassword();
				break;
			case 3:
				DeleteTickets();
				break;
			case 4:
				return;

			default:

				break;
		}}



	}
	//fuction for admin to view users details
	private void ViewUsersDetails()throws SQLException{
		Statement stmt = connection.createStatement();

		String sql = " SELECT * FROM users";

		ResultSet resultSet = stmt.executeQuery(sql);

		String fullName,MobileNumber,email,username, password;
		int ID;
		System.out.println("ID   |fullName      |       MobileNumber     |       email       |          username     |            password\n");
		while (resultSet.next()) {
			ID = resultSet.getInt(1);
			fullName = resultSet.getString(2);
			MobileNumber= resultSet.getString(3);
			email= resultSet.getString(4);
			username = resultSet.getString(5);
			password = resultSet.getString(6);
			System.out.println(ID +"   "+ fullName + "          " + MobileNumber + "           " + email+ "             " +
					username + "               " +password+"" );

		}


	}


	}









